﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace WebApiApp.Filters
{
    public class CustomFilter : Attribute, IActionFilter
    {
        private readonly ILogger<CustomFilter> _logger;
        public CustomFilter(ILogger<CustomFilter> logger)
        {
            _logger = logger;
        }
        public void OnActionExecuted(ActionExecutedContext context)
        {
            _logger.LogInformation("\n Bitti \n");
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            _logger.LogInformation("\n Bashladi \n");
        }
    }
}
