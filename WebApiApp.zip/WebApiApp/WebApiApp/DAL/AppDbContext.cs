﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiApp.Models;

namespace WebApiApp.DAL
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options):base(options)
        {
        }

        public DbSet<Post> Posts { get; set; }
        public DbSet<Comment> Comments { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Post>().HasData(
                new Post { Id=1,Title="title1",Body="post body 1"},
                new Post { Id = 2, Title = "title2", Body = "post body 2" },
                new Post { Id = 3, Title = "title3", Body = "post body 3" }
            );

            modelBuilder.Entity<Comment>().HasData(
                new Comment { Id = 1,Message="1 Comment",PostId=1 },
                new Comment { Id = 2,Message="2 Comment",PostId=1 },
                new Comment { Id = 3,Message="3 Comment",PostId=1 },
                new Comment { Id = 4,Message="1 Comment",PostId=2 },
                new Comment { Id = 5,Message="2 Comment",PostId=2 }
            );
        }
    }
}
