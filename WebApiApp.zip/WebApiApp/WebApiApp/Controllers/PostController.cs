﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using WebApiApp.DAL;
using WebApiApp.Filters;
using WebApiApp.Models;

namespace WebApiApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ILogger _logger;
        public PostController(AppDbContext context, ILogger<PostController> logger)
        {
            _context = context;
            _logger = logger;
        }
        // GET: api/Post
        /// <summary>
        /// Get all Post
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [TypeFilter(typeof(CustomFilter))]
        public IEnumerable<object> Get()
        {
            //_logger.LogInformation("\n Get() method worked - for all data \n");
            return _context.Posts.Include(p=>p.Comments).Select(p=>new { 
                p.Id,
                p.Title,
                p.Body,
                Comment=p.Comments.Where(c=>c.Id>2).ToList()
            }).ToList();
        }

        // GET: api/Post/5
        /// <summary>
        /// Get post for sending id
        /// </summary>
        /// <param name="id">Required</param>
        /// <returns></returns>
        [HttpGet("{id}", Name = "Get")]
        public async Task<ActionResult<Post>> Get(int id)
        {
            _logger.LogInformation("\n Get() method worked - for one data \n");
            Post post =await _context.Posts.FindAsync(id);
            if (post == null) return NotFound();
            return post;
        }

        // POST: api/Post
        /// <summary>
        /// For creating post
        /// </summary>
        /// <param name="post">Post object</param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] Post post)
        {
            if (!ModelState.IsValid) return BadRequest();
            await _context.Posts.AddAsync(post);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // PUT: api/Post/5
        /// <summary>
        /// For updating Post
        /// </summary>
        /// <param name="id">updating post id</param>
        /// <param name="post">updating post data</param>
        /// <returns></returns>
        [HttpPut("{id}")]
        public async Task<ActionResult> Put(int id, [FromBody] Post post)
        {
            if (id != post.Id) return BadRequest();
            Post dbPost =await _context.Posts.FindAsync(id);
            if (dbPost == null) return NotFound();

            dbPost.Title = post.Title;
            dbPost.Body = post.Body;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // DELETE: api/ApiWithActions/5
        /// <summary>
        /// For delete post
        /// </summary>
        /// <param name="id">deleted post id</param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            Post post =await _context.Posts.FindAsync(id);
            if (post == null) return NotFound();
            _context.Posts.Remove(post);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
